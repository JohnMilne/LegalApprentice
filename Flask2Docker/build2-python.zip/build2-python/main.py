from flask import Flask, render_template, request
from flask_restplus import Api, Resource, fields
from flask_cors import CORS
import certifi


from elasticsearch import Elasticsearch


# create all the 'GETs ' in here
app = Flask(__name__)
CORS(app)

api = Api(app, version='1.1', title='DPMIA API',
          description='A simple search API',
          )

##############################################
# connect to Elastic
#es = Elasticsearch(port=9200)
try:
    es = Elasticsearch(
        ['https://39d398514eb541c7814bf2fd3f3ed673.us-east-1.aws.found.io:9243'],
        http_auth=('elastic', 'l0txCHcwzlmbL5tosJ6uDN1z'),
        port=20202,
        use_ssl=True,
        verify_certs=True,
        ca_certs=certifi.where(),
    )
    print("Connected", es.info())

except Exception as ex:

    print("Error:", ex)

##########################################


ns = api.namespace('dpmElastic', description='search for things in dpm201909')


todo = api.model('dpm201909', {
    'id': fields.Integer(readOnly=True, description='The task unique identifier'),
    'task': fields.String(required=True, description='The task details')
})

@app.route('/hello')
def helloIndex():
    return 'Hello World from Python Flask!'


# Fields for dropdown menus

def get_fields():

    res = es.search_template(
        index="dpm201909",
        body={
            "id": "dpm_get_filters_template5",
            "params": {
                "dpm_query": ""  # we query nothing so it pulls all possible fields
            }})

    dictv = {}
    dictv['query_term'] = 'null'
    dictv['has_errors'] = False
    dictv['error_message'] = 1
    dictv['payload_count'] = len(res['aggregations'])

    dict_pay = {}

    fields = []
    for item in res['aggregations']:
        if item != 'entities_all':
            fields.append(item)

    dictv['payload'] = fields

    return dictv


@ns.route('/Fields')  # return fields for dropdowns
class FieldNames(Resource):
    '''get field names'''
    @ns.doc('obtain potential fields names to populate the drop down menus')
    def get(self):
        '''get fields'''
        res = get_fields()

        return res


####################################################################
# GET all possible values for each field depending on the search_term

def get_values_sidebar(search_term):
    res = es.search_template(
        index="",
        body={
            "id": "dpm_get_filters_template5",
            "params": {
                "dpm_query": search_term
            }})

    dictv = {}
    dictv['query_term'] = search_term
    dictv['has_errors'] = False
    dictv['error_message'] = 1
    dictv['payload_count'] = len(res['aggregations'])

    dict_pay = {}
    for item in res['aggregations']:
        g = res['aggregations'][item]['buckets']
        flist = []
        for j in range(0, len(g)):
            flist.append(g[j])
        dict_pay[item] = flist
    dict_pay.pop('entities_all')

    dictv['payload'] = [dict_pay]

    return dictv


@ns.route('/ValuesSidebar/<string:query>')
class FieldNamesSidebar(Resource):
    '''get field name values'''
    @ns.doc('obtain field name values to populate the sidebar. must have somthing in the query to get this to populate')
    def get(self, query):
        '''get field values'''
        res = get_values_sidebar(query)

        return res


##########################################
# graph query
def get_graph(search_term='null', node_shape1='null', node_shape2='null', connections=5, min_doc=2, exclude={}):

    section_title_vals = ", ".join(exclude['section_title'])
    leadership_vals = ", ".join(exclude['leadership'])
    directorate_vals = ", ".join(exclude['directorate'])
    function_vals = ", ".join(exclude['function'])
    type_vals = ", ".join(exclude['type'])
    department_vals = ", ".join(exclude['department'])
    sector_vals = ", ".join(exclude['sector'])
    domain_vals = ", ".join(exclude['domain'])

    if node_shape1 != 'null':
        node_shape1 = node_shape1 + '.keyword'

    if node_shape2 != 'null':
        node_shape2 = node_shape2 + '.keyword'

    if search_term == 'null':
        errm = "please enter a search term"
        pay = {None}
        errorTF = True

    elif node_shape1 != 'null' or node_shape2 != 'null':
        res = es.xpack.graph.explore(
            index="dpm201909",
            body={
                  "query": {
                      "bool": {
                          "must": {
                              "multi_match": {
                                  "query": search_term,
                                  "fields": [
                                      "text",
                                      "section_title",
                                      "function",
                                      "entities_all"
                                  ],
                                  "operator": "and",
                                  "slop": 1
                              }
                          },
                          "must_not": [],
                          "should": {
                              "multi_match": {
                                  "query": search_term,
                                  "fields": [
                                      "text",
                                      "section_title",
                                      "function",
                                      "entities_all"
                                  ],
                                  "operator": "and",
                                  "slop": 1
                              }
                          }
                      }
                  },
                "connections": {
                    "vertices": [
                        {
                            "field": node_shape1,
                            "size": connections,
                            "min_doc_count": min_doc
                        },
                        {
                            "field": node_shape2,
                            "size": connections,
                            "min_doc_count": min_doc
                        }
                    ]
                  },
                "vertices": [
                    {
                        "field": node_shape1,
                        "size": connections,
                        "min_doc_count": min_doc
                    },
                    {
                        "field": node_shape2,
                        "size": connections,
                        "min_doc_count": min_doc
                    }
                  ]
            })

        pay = {}
        pay['vertices'] = res['vertices']
        pay['connections'] = res['connections']
        errm = ''
        errorTF = False

    else:
        pay = {None}
        errorTF = True
        errm = "please choose a field for the node shape(s)"

    dictv = {}
    dictv['query_term'] = search_term
    dictv['has_errors'] = errorTF
    dictv['error_message'] = errm
    dictv['payload_count'] = len(pay)
    dictv['payload'] = [pay]

    return dictv


def get_graph_srs(search_term='null', node_shape1='null', node_shape2='null', connections=5, min_doc=2, exclude={}):

    notmatch = []

    # section_title_vals = ", ".join(exclude['section_title'])
    # leadership_vals = ", ".join(exclude['leadership'])
    # directorate_vals = ", ".join(exclude['directorate'])
    # function_vals = ", ".join(exclude['function'])
    # type_vals = ", ".join(exclude['type'])
    # department_vals = ", ".join(exclude['department'])
    # sector_vals = ", ".join(exclude['sector'])
    # domain_vals = ", ".join(exclude['domain'])

    if node_shape1 != 'null':
        node_shape1 = node_shape1 + '.keyword'

    if node_shape2 != 'null':
        node_shape2 = node_shape2 + '.keyword'

    if search_term == 'null':
        errm = "please enter a search term"
        pay = {None}
        errorTF = True

    elif node_shape1 != 'null' or node_shape2 != 'null':
        res = es.xpack.graph.explore(
            index="dpm201909",
            body={
                "query": {
                    "bool": {
                        "must": {
                            "multi_match": {
                                "query": search_term,
                                "fields": [
                                    "text",
                                    "section_title",
                                    "function",
                                    "entities_all"
                                ],
                                "operator": "and",
                                "slop": 1
                            }
                        },
                        "must_not": notmatch,
                        "should": {
                            "multi_match": {
                                "query": search_term,
                                "fields": [
                                    "text",
                                    "section_title",
                                    "function",
                                    "entities_all"
                                ],
                                "operator": "and",
                                "slop": 1
                            }
                        }
                    }
                },
                "connections": {
                    "vertices": [
                        {
                            "field": node_shape1,
                            "size": connections,
                            "min_doc_count": min_doc
                        },
                        {
                            "field": node_shape2,
                            "size": connections,
                            "min_doc_count": min_doc
                        }
                    ]
                },
                "vertices": [
                    {
                        "field": node_shape1,
                        "size": connections,
                        "min_doc_count": min_doc
                    },
                    {
                        "field": node_shape2,
                        "size": connections,
                        "min_doc_count": min_doc
                    }
                ]
            })

        pay = {}
        pay['vertices'] = res['vertices']
        pay['connections'] = res['connections']
        errm = ''
        errorTF = False

    else:
        pay = {None}
        errorTF = True
        errm = "please choose a field for the node shape(s)"

    dictv = {}
    dictv['query_term'] = search_term
    dictv['has_errors'] = errorTF
    dictv['error_message'] = errm
    dictv['payload_count'] = len(pay)
    dictv['payload'] = [pay]

    return dictv


build_graph_model = api.model("graph", {
    "query": fields.String(description="the query from the search bar", required=True, default="null", example='tax'),
    "node_shape1": fields.String(description="the field chosen for node shape 1", default="department", required=True, example="function"),
    "node_shape2": fields.String(description="the field chosen for node shape 2", default="null", required=False, example="domain"),
    "connections": fields.Integer(description="the number of maximum connections for each node", required=False, default=5, example=5),
    "min_doc": fields.Integer(description="the minimum number of documents for each node", required=False, default=2, example=2),
    "exclude": fields.Raw(description="dictionary of excluded items", required=False, default={}, example={})
})


@ns.route('/BuildGraph')  # return fields for dropdowns
class BuildGraph(Resource):
    '''get nodes and connections for graph'''
    @ns.doc('get nodes (verticies) and connections for the graph')
    @api.expect(build_graph_model)
    def post(self):
        """
        get shapes information to build graph
        """
        payload_g = api.payload
        res = get_graph_srs(payload_g['query'], payload_g['node_shape1'],
                            payload_g['node_shape2'], payload_g['connections'], payload_g['exclude'])
        # return payload_g, 200
        return res, 200


def tagger_search_request(search_term):
    res = es.search(
        scroll="2m",
        index="dpm201909",
        #  size=100,
        body={
            "query": {
                "bool": {
                    "must": {
                        "match": {
                            "text": search_term
                        }
                    },
                    "should": {
                        "match_phrase": {
                            "text": search_term
                        }
                    }
                }
            },
            "size": 10
        }
    )
    result = res['hits']['hits']
    list_results = []
    for i in range(0, len(result)):
        info = []
        source = result[i]['_source']
        info.append(source['CHAPTER_HEAD'])
        info.append(source['SUBCHAP_HEAD'])
        info.append(source['PART_HEAD'])
        info.append(source['SECTION_HEAD'])
        info_whole = "; ".join(info)
        list_results.append(info_whole)

    dictv = {}
    dictv['query_term'] = search_term
    dictv['has_errors'] = False
    dictv['error_message'] = ""
    dictv['payload_count'] = len(list_results)
    dictv['payload'] = list_results

    return dictv


@ns.route('/GetTextChoices/<string:query>')
class TextTagger(Resource):
    '''search for a term to pull a selection of documents to tag. returns a list of choices'''
    @ns.doc('query or part_number')
    def get(self, query):
        '''search agency'''
        return tagger_search_request(query)


def get_context_func(text):
    chapter_head = text.split(';')[0]
    subchap_head = text.split(';')[1]
    part_head = text.split(';')[2]
    section_head = text.split(';')[3]

    res = es.search(
        scroll="2m",
        index="dpm201909",
        body={
            "_source": ["NODE", "TEXT"],
            "query": {
                "bool": {
                    "must": [
                        {
                            "match": {
                                "CHAPTER_HEAD": chapter_head
                            }
                        },
                        {
                            "match": {
                                "SUBCHAP_HEAD": subchap_head
                            }
                        },
                        {
                            "match": {
                                "PART_HEAD": part_head
                            }
                        },
                        {
                            "match": {
                                "SECTION_HEAD": section_head
                            }
                        }
                    ]
                }
            }
        }
    )
    result = res['hits']['hits']
    source = []
    for i in range(len(result)):
        source.append(result[i]['_source'])

    dictv = {}
    dictv['query_term'] = text
    dictv['has_errors'] = False
    dictv['error_message'] = ""
    dictv['payload_count'] = len(source)
    dictv['payload'] = source

    return dictv


get_context_model = api.model("context", {
    "selection": fields.String(description="the string that is selected", required=True, default="null", example='CHAPTER I - INTERNAL REVENUE SERVICE, DEPARTMENT OF THE TREASURY (CONTINUED); SUBCHAPTER A - INCOME TAX (CONTINUED); PART 1 - INCOME TAXES (CONTINUED); § 1.903-1   Taxes in lieu of income taxes.')})


@ns.route('/GetContextTagger')  # return fields for dropdowns
class GetContext(Resource):
    '''get the text from surrounding documents for tagging'''
    @ns.doc('get the text from surrounding documents for tagging')
    @api.expect(get_context_model)
    def post(self):
        """
        get surrounding documents for context
        """
        payload_tag = api.payload
        res = get_context_func(payload_tag['selection'])

        return res, 200

def get_spider_func(query='null', selected_shape='null', not_selected_shape='null', node = 'null', connections=5, min_doc=2,\
                    exclude= [{'section_title': [],\
                                'leadership': [],\
                                'directorate':[],\
                                'function': [],\
                               'type': [],\
                               'department': [],\
                              'sector': [],\
                             'agency':[],\
                            'domain':[]}]):

    section_title_vals = ", ".join(exclude[0]['section_title'])
    leadership_vals = ", ".join(exclude[0]['leadership'])
    directorate_vals = ", ".join(exclude[0]['directorate'])
    function_vals = ", ".join(exclude[0]['function'])
    type_vals = ", ".join(exclude[0]['type'])
    department_vals = ", ".join(exclude[0]['department'])
    sector_vals = ", ".join(exclude[0]['sector'])
    domain_vals = ", ".join(exclude[0]['domain'])

    if selected_shape != 'null':
            selected_shape = selected_shape + '.keyword'

    if not_selected_shape != 'null':
            not_selected_shape = not_selected_shape + '.keyword'

    if query == 'null':
            errm =  "please enter a search term"
            pay =  {None}
            errorTF = True

    res = es.xpack.graph.explore(
        index="dpm201909",
        body={
              "query": {
                "bool": {
                  "must": {
                    "multi_match": {
                      "query": query,
                      "fields": [
                        "text",
                        "section_title",
                        "function",
                        "entities_all"
                      ],
                      "operator":"and",
                      "slop": 1
                    }
                  },
                  "must_not": [{
                    "match": {
                      "function": function_vals
                    }
                  },
                  {
                    "match":{
                      "section_title" : section_title_vals
                    }
                  },
                  {
                    "match":{
                      "department" :department_vals
                    }
                  },
                  {
                    "match":{
                      "leadership" :leadership_vals
                    }
                  },
                  {
                    "match":{
                      "domain" :domain_vals
                    }
                  },
                  {
                    "match":{
                      "directorate" :directorate_vals
                    }
                  },
                  {
                    "match":{
                      "type" :type_vals
                    }
                  },
                  {
                    "match":{
                      "sector" :sector_vals
                    }
                  }],
                  "should": {
                    "multi_match": {
                      "query": query,
                      "fields": [
                        "text",
                        "section_title",
                        "function",
                        "entities_all"
                      ],
                      "operator":"and",
                      "slop": 1
                    }
                  }
                }
              },
            "connections": {
                "vertices": [
                    {
                        "field": selected_shape ,
                        "include": [node],
                        "size": connections,
                        "min_doc_count": min_doc
                    }
                ]
            },
            "vertices": [
                {
                    "field": selected_shape,
                    "size": connections,
                    "min_doc_count": min_doc
                },
                {
                    "field": not_selected_shape,
                    "size": connections,
                    "min_doc_count": min_doc
                }
            ]
        })

    pay = {}
    pay['vertices'] = res['vertices']
    pay['connections'] = res['connections']
    errm = ''
    errorTF = False




    dictv = {}
    dictv['query_term'] = query
    #dictv['has_errors'] = errorTF
    #dictv['error_message'] = errm
    dictv['payload_count'] = len(pay)
    dictv['payload'] = [pay]


    return dictv




get_spider_model = api.model("spider", {
    "query": fields.String(description="the query from the search bar", required=True, default="null",example='tax'),
    "selected_shape": fields.String(description="the shape that is selected", required=True, default="null",example='function'),
    "not_selected_shape": fields.String(description="the shape that is not selected", required=True, default="null",example='domain'),
    "node": fields.String(description="the node that is selected", required=True, default="null",example='reimbursement')})


@ns.route('/GetSpider') # return fields for dropdowns
class GetSpider(Resource):
    '''get the node(s) for spidering out'''
    @ns.doc('get the  node(s) for spidering out so a new graph can be drawn')

    @api.expect(get_spider_model)
    def post(self):
        """
        get nodes for spidering
        """
        payload_spider = api.payload
        res = get_spider_func(payload_spider['query'],payload_spider['selected_shape'],payload_spider['not_selected_shape'],payload_spider['node'])

        return res, 200        


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)

from flask import Flask
from flask_restplus import Api, Resource, fields
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

api = Api(app, version='1.0', title='Hello Swagger',
          description='A simple swagger API',
          )

ns = api.namespace('helloSwag', description='project namespace')


@ns.route('/Greet')  # return fields for dropdowns
class HelloAll(Resource):
    @ns.doc('get method on class')
    def get(self):
            return 'Hello World from HelloAll'


@app.route('/hello')
def helloIndex():
    return 'Hello World from Python Flask!'

app.run(host='0.0.0.0', port= 5000)